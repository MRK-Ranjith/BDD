package login;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
// pageBean.HotelLoginPageFactory;
import pageBean.HotelLoginPageFactory;

public class LoginStepDefination {

	private WebDriver driver;
	private HotelLoginPageFactory loginPageFactory;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cm8\\Desktop\\Module4\\Cucumber\\YoginiHotelBookingDemo\\libs\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
	}

	@Given("user is on {string} Page")
	public void user_is_on_Page(String string) {
		driver.get(
				"file:///C:/Users/cm8/Desktop/Module4/Cucumber/YoginiHotelBookingDemo/src/main/java/com/cg/page/"+string+".html");
		loginPageFactory = new HotelLoginPageFactory(driver);
	}

	@When("user enters invalid UserName")
	public void user_enters_invalid_UserName() {
		loginPageFactory.setUserName("");
	}

	@When("user click the login button and print {string}")
	public void user_click_the_login_button(String message) throws InterruptedException {
		if (loginPageFactory.getUserName().equals("") || loginPageFactory.getPassword().equals("")) {
			loginPageFactory.setError(message);
		} else {
			Thread.sleep(3000);
			loginPageFactory.setLoginButton();
		}
	}
	
	@When("user enters invalid password")
	public void user_enters_invalid_password() {
		loginPageFactory.setPassword("");
	}
	
	@When("user enters valid {string} and  {string}")
	public void user_enters_valid_and(String username, String password) {
		loginPageFactory.setUserName(username);
		loginPageFactory.setPassword(password);
	}

	@When("user click the login button and display {string} page")
	public void user_click_the_login_button_and_display_page(String string) throws InterruptedException {
		if (loginPageFactory.getUserName().equals("") || loginPageFactory.getPassword().equals("")) {
			loginPageFactory.setError("please eneter username and password correctly");
		} else {
		Thread.sleep(3000);
		driver.get(
				"file:///C:/Users/cm8/Desktop/Module4/Cucumber/YoginiHotelBookingDemo/src/main/java/com/cg/page/"+string+".html");
		}
	}


}
