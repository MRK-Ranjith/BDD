/*package login;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
// pageBean.HotelLoginPageFactory;
import pageBean.HotelLoginPageFactory;

public class LoginStepDefination_del {

	private WebDriver driver;
	private HotelLoginPageFactory loginPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cm8\\Desktop\\Module4\\Cucumber\\YoginiHotelBookingDemo\\libs\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^User is on 'login' Page$")
	public void user_is_on_login_Page() throws Throwable {
	
		driver.get("file:///C:/Users/cm8/Desktop/Module4/Cucumber/YoginiHotelBookingDemo/src/main/java/com/cg/page/Login.html");
		
		//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			loginPageFactory = new HotelLoginPageFactory(driver);

	}

	@When("^user enters invalid UserName$")
	public void user_enters_invalid_UserName() throws Throwable {
		loginPageFactory.setUserName("");
		Thread.sleep(5000);
		loginPageFactory.setLoginButton();
		
		
	}

	@Then("^display 'Please Enter UserName'$")
	public void display_Please_Enter_UserName() throws Throwable {
		String expectedMessage="* Please enter userName.";
		String actualMessage=loginPageFactory.getUsernameError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();	
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		loginPageFactory.setUserName("yogini");
		loginPageFactory.setPassword("");
		Thread.sleep(5000);
		loginPageFactory.setLoginButton();

	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() throws Throwable {
		String expectedMessage="* Please enter password.";
		String actualMessage=loginPageFactory.getPasswordError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();	

	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		loginPageFactory.setUserName("Capgemini");
		loginPageFactory.setPassword("capg1234");
		Thread.sleep(5000);
		loginPageFactory.setLoginButton();
	
	}

	@Then("^display 'HotelBooking' Page$")
	public void display_HotelBooking_Page() throws Throwable {
		Thread.sleep(5000);
		driver.close();
	}
	
	@When("user enters invalid username and password")
	public void user_enters_invalid_username_and_password() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display {string}")
	public void display(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}



}
*/