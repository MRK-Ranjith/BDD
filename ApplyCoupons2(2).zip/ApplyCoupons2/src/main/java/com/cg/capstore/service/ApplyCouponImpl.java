package com.cg.capstore.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capstore.dao.CapStoreDao;
import com.cg.capstore.entities.OrderDetails;
import com.cg.capstore.exception.ApplicationException;

@Service
@Transactional
public class ApplyCouponImpl implements IApplyCoupon {
	@Autowired private CapStoreDao dao;
	
	//@Autowired private OrderDetails order;
	
	@Override
	@Transactional
	public OrderDetails findByCouponCode(String ccode) {
		// TODO Auto-generated method stub
		System.out.println("Finding coupon: "+ccode);
		Optional<OrderDetails> temp = dao.findById(ccode);
		System.out.println(temp.get());
		if(!temp.isPresent()) {
			throw new ApplicationException("Coupon not found "+ccode);
		}
		else {	
			System.out.println("Coupon applied successfully");	
			applyCoupon(ccode);
		}
		return temp.get();
	}

	@Override
	public OrderDetails applyCoupon(String ccode) {
		// TODO Auto-generated method stub
		Optional<OrderDetails> opt = dao.findById(ccode);
		OrderDetails od = opt.get();
		Double camount = od.getCouponamount();
		Double orderprice = od.getOrdertotal();
		Double finalPrice = orderprice-camount;
		od.setOrderfinalprice(finalPrice);
		dao.save(od);
		System.out.println("Price after coupon applied: "+finalPrice);
		return od;
		
	}

	
}
