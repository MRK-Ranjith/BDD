package com.cg.capstore.service;

import com.cg.capstore.entities.OrderDetails;

public interface IApplyCoupon 
{
 OrderDetails findByCouponCode(String ccode);
 public OrderDetails applyCoupon(String ccode);
}
