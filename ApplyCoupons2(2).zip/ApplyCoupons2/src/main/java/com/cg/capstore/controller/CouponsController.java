package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entities.OrderDetails;
import com.cg.capstore.service.IApplyCoupon;


@RestController
@RequestMapping("/apply")
public class CouponsController {
	
	@Autowired
	private IApplyCoupon applycoupon;
	
	//applying coupon method by the user
		@GetMapping("/verifyingcoupon/{couponcode}")
		public ResponseEntity<OrderDetails> applycoupon(@PathVariable String couponcode)
		{	
			OrderDetails couponResponse = applycoupon.findByCouponCode(couponcode);	
			return new ResponseEntity<OrderDetails>(couponResponse,HttpStatus.OK);
		}
		
		@PutMapping(value = "/applycoupon")
		public OrderDetails couponapply(@RequestParam("coupon") String couponcode) 
		{		
			return applycoupon.applyCoupon(couponcode);
		}
		
}
