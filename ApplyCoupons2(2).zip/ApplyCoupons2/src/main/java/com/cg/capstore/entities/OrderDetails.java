package com.cg.capstore.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@Table(name="orderdetails")
@XmlRootElement
public class OrderDetails implements Serializable{

		
		@Column(name="orderid")
		private String orderid;
		
		@Column(name="ordertotal")
		private Double ordertotal;
		
		@Column(name="orderfinalprice")
		private Double orderfinalprice;
		@Id
		@Column(name="couponcode")
		private String couponcode;
		
		@Column(name="couponamount")
		private Double couponamount;
		
		public Double getCouponamount() {
			return couponamount;
		}

		public void setCouponamount(Double couponamount) {
			this.couponamount = couponamount;
		}

		public Double getOrderfinalprice() {
			return orderfinalprice;
		}

		public void setOrderfinalprice(Double orderfinalprice) {
			this.orderfinalprice = orderfinalprice;
		}

		
		public String getCouponcode() {
			return couponcode;
		}

		public void setCouponcode(String couponcode) {
			this.couponcode = couponcode;
		}

		public String getOrderid() {
			return orderid;
		}

		public void setOrderid(String orderid) {
			this.orderid = orderid;
		}

		public Double getOrdertotal() {
			return ordertotal;
		}

		public void setOrdertotal(Double ordertotal) {
			this.ordertotal = ordertotal;
		}

		public OrderDetails() {
			// TODO Auto-generated constructor stub
		}
		public OrderDetails(String orderid, Double ordertotal, Double orderfinalprice, String couponcode,
				Double couponamount) {
			super();
			this.orderid = orderid;
			this.ordertotal = ordertotal;
			this.orderfinalprice = orderfinalprice;
			this.couponcode = couponcode;
			this.couponamount = couponamount;
		}

		
}
